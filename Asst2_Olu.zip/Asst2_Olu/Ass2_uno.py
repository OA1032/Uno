import cv2
import numpy as np 

img = cv2.imread('Desktop/Uno_card_images/b0.jpg')

#pixel values in the original images
input_points = np.float32([[83,18],[342,53],[14,389],[295,436]])

# Output image size 
width = 400 
height = int(width* 1.414) # A4 page #640

#Desired points values in the other output image 
converted_points = np.float32([[0,0],[width,0],[0,height],[width,height]])

#perspective Transformation 
matrix = cv2.getPerspectiveTransform(input_points, converted_points)

cv2.imshow('original',img)

cv2.waitKey(0)